use std::path::Path;
use std::time::Duration;

use ikb_core::config::Config;

#[test]
fn load_repo_config_yml() {
    let path = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("..")
        .join("..")
        .join("config.yml");
    let cfg = match Config::load_from_path(&path) {
        Ok(v) => v,
        Err(e) => panic!("load config.yml failed: {}", e),
    };
    assert!(!cfg.ikuai_url.is_empty());
    assert!(cfg.max_number_of_one_records.isp > 0);
}

#[test]
fn defaults_match_go_expectations() {
    let yaml = r#"
ikuai-url: http://192.168.9.1
username: admin
password: pass
cron: ""
webui: {}
MaxNumberOfOneRecords: {}
stream-domain:
  - interface: wan1
    url: https://example.com
"#;

    let mut cfg: Config = match serde_yaml::from_str(yaml) {
        Ok(v) => v,
        Err(e) => panic!("parse failed: {}", e),
    };
    cfg.apply_defaults();

    assert_eq!(cfg.webui.cdn_prefix, "https://cdn.jsdelivr.net/npm");
    assert_eq!(cfg.max_number_of_one_records.isp, 5000);
    assert_eq!(cfg.max_number_of_one_records.ipv4, 1000);
    assert_eq!(cfg.max_number_of_one_records.ipv6, 1000);
    assert_eq!(cfg.max_number_of_one_records.domain, 5000);
    assert_eq!(
        cfg.stream_domain.first().map(|v| v.tag.as_str()),
        Some("wan1")
    );
    assert_eq!(cfg.add_wait, Duration::from_secs(0));
}

#[test]
fn stream_ipport_addr_inv_defaults_to_zero_when_missing() {
    let yaml = r#"
ikuai-url: http://192.168.9.1
username: admin
password: pass
cron: ""
stream-ipport:
  - type: "1"
    opt-tagname: RouteA
    interface: ""
    nexthop: 192.168.1.2
    src-addr: 192.168.1.10-192.168.1.20
    src-addr-opt-ipgroup: ""
    ip-group: TagA
    mode: 0
    ifaceband: 0
"#;

    let cfg = Config::load_from_yaml_str(yaml).expect("config should load");
    let item = cfg
        .stream_ipport
        .first()
        .expect("stream-ipport item should exist");

    assert_eq!(item.src_addr_inv, 0);
    assert_eq!(item.dst_addr_inv, 0);
    assert_eq!(item.prio, 0);
}

#[test]
fn stream_ipport_addr_inv_is_normalized_to_binary_flags() {
    let yaml = r#"
ikuai-url: http://192.168.9.1
username: admin
password: pass
cron: ""
stream-ipport:
  - type: "1"
    opt-tagname: RouteA
    interface: ""
    nexthop: 192.168.1.2
    src-addr: 192.168.1.10-192.168.1.20
    src-addr-opt-ipgroup: ""
    src-addr-inv: 2
    ip-group: TagA
    dst-addr-inv: -1
    mode: 0
    ifaceband: 0
"#;

    let cfg = Config::load_from_yaml_str(yaml).expect("config should load");
    let item = cfg
        .stream_ipport
        .first()
        .expect("stream-ipport item should exist");

    assert_eq!(item.src_addr_inv, 0);
    assert_eq!(item.dst_addr_inv, 0);
}

#[test]
fn stream_ipport_prio_is_loaded_when_configured() {
    let yaml = r#"
ikuai-url: http://192.168.9.1
username: admin
password: pass
cron: ""
stream-ipport:
  - type: "1"
    opt-tagname: RouteA
    interface: ""
    nexthop: 192.168.1.2
    src-addr: 192.168.1.10-192.168.1.20
    src-addr-opt-ipgroup: ""
    ip-group: TagA
    prio: 63
    mode: 0
    ifaceband: 0
"#;

    let cfg = Config::load_from_yaml_str(yaml).expect("config should load");
    let item = cfg
        .stream_ipport
        .first()
        .expect("stream-ipport item should exist");

    assert_eq!(item.prio, 63);
}

#[test]
fn stream_ipport_mode_6_is_loaded_when_configured() {
    let yaml = r#"
ikuai-url: http://192.168.9.1
username: admin
password: pass
cron: ""
stream-ipport:
  - type: "0"
    opt-tagname: RouteA
    interface: wan1
    nexthop: ""
    src-addr: 192.168.1.10-192.168.1.20
    src-addr-opt-ipgroup: ""
    ip-group: TagA
    prio: 0
    mode: 6
    ifaceband: 0
"#;

    let cfg = Config::load_from_yaml_str(yaml).expect("config should load");
    let item = cfg
        .stream_ipport
        .first()
        .expect("stream-ipport item should exist");

    assert_eq!(item.mode, 6);
}
